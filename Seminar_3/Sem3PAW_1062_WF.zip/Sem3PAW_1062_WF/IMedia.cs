﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sem3PAW_1062_WF
{
    interface IMedia
    {
        float calculeazaMedie();
    }
}
