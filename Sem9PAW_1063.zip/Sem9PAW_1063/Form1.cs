﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Sem9PAW_1063
{
    public partial class Form1 : Form
    {
        double[] vect = new double[30];
        int nrElem = 0;
        bool vb = false;

        Graphics gr;

        const int marg = 10;


        public Form1()
        {
            InitializeComponent();
        }

        private void incarcaDateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader("fisier.txt");
            string linie = null;
            while((linie = sr.ReadLine())!=null)
            {
                vect[nrElem] = Convert.ToDouble(linie);
                nrElem++;
                vb = true;
            }
            sr.Close();
            panel1.Invalidate();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            gr = e.Graphics;
            if(vb==true)
            {
                Rectangle rec = new Rectangle(panel1.ClientRectangle.X+marg,
                    panel1.ClientRectangle.Y+marg,
                    panel1.ClientRectangle.Width-2*marg,
                    panel1.ClientRectangle.Height-2*marg);
                Pen pen = new Pen(Color.Red, 3);
                gr.DrawRectangle(pen, rec);
            }
        }
    }
}
