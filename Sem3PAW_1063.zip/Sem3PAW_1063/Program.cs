﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sem3PAW_1063
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
